//定义user数据表对象
const user=wx.cloud.database().collection('user')
Page({
  data: {
    openid:'',
    //存放从数据库拿到的数组
    reportArry:''
  },
  onLoad: function (options) {
    const that = this 
    console.log(options)
    that.setData({
      openid:options.openid
    })
    //拿到本地中上报的记录
    wx.getStorage({
      key:"myReport",
      success(res){
        console.log("获取本地成功！",res.data)
        that.setData({
          reportArry:res.data
         })
      },fail(res){
        console.log(res)
      }
    })
  },
    //下拉刷新
    onPullDownRefresh () {
      var that = this
      wx.showNavigationBarLoading(); 
      //显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框
      wx.showLoading({
        title: '正在努力刷新',
      })
      //向后台发起查询请求
      //根据openid查询拿到report数组
      user.where({_openid:that.data.openid}).get({
      success(res){
        console.log("根据openid查询成功",res.data[0].report)
        //将拿到的report数组放到页面数组中
        // that.data.reportArry.push(res.data[0].report)
        that.setData({
          reportArry:res.data[0].report
        })
        //主动调用 wx.hideLoading 关闭提示框
        wx.hideLoading()
        console.log("页面reportArry数组",that.data.reportArry)
        //将向后台发起的请求拿到的数据存到本地（异步存储）
        wx.setStorage({
          key:"myReport",
          data:res.data[0].report,
        })
        },fail(res){
        console.log("根据openid查询失败",res)
      }
    })
    wx.stopPullDownRefresh()
    }
})