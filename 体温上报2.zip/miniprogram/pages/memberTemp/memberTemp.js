//定义获取系统当前时间
var myDate=new Date();
//定义user数据表对象
const user=wx.cloud.database().collection('user')
//引用command方法
const _ =  wx.cloud.database().command
Page({
  data: {
  isMem:true,
  openid:'',
  //未上报
  notReported:[],
  //已上报
  Reported:[],
  },

  onLoad: function (options) {
  this.data.openid=options.openid
  },
  onShow: function () {
    const that = this
    let Year = myDate.getFullYear();
    let Month=myDate.getMonth()+1;
    let Date=myDate.getDate();
    let Today=Year+"年"+Month+"月"+Date+"日"
   //先拿到自己账号下的member以确定自己的小组成员
   user.where({_openid:that.data.openid}).get({
     success(res){
       console.log("根据openid查询成功！",res.data[0].member)
       let mem =res.data[0].member//存放用户当前小组成员
       if(mem==undefined){//无小组成员
        that.data.isMem=false
        console.log("您没有小组成员，如需添加小组成员请到小组成员管理中添加")
       }else{//有小组成员
        let len =res.data[0].member.length // 存放当前小组数组的长度
        //利用for循环逐个遍历,拿到小组成员上报的体温数据
        for(let i=0;i<res.data[0].member.length;i++)
        {  
          //拿到第i个当前小组成员的name number major
          let  iname=res.data[0].member[i].name
          let  inumber=res.data[0].member[i].number
          let  imajor=res.data[0].member[i].major
          //利用第i个小组成员信息查询该小组成员是否上报信息
          user.where({
            name:iname,
            number:inumber,
            major:imajor
          }).get({
            success(res){
              //未上报名单对象,封装成对象
              let notRep ={
                  name:iname,
                  number:inumber,
                  major:imajor 
              }
              console.log("查询第",i,"个成员成功",res.data)
              /**被认定未上报的名单
               * 1.用户没有绑定学号信息，未激活状态
               * 2.用户激活了但是一次都没有上报过体温(没有上报过就没有report字段)
               * 3.用户当天没有上报体温（字段中的日期和当天不一致）
               */
              if(res.data.length==0){//用户没有绑定信息，查不到该小组成员的信息
                // number name major封装成对象并push进未上报数组
                let arr1=[...that.data.notReported]
                arr1.push(notRep)
                that.setData({
                  notReported:arr1
                })
              }else{//查询到该小组成员的信息
                //拿到该小组成员的report字段数组长度和
                if(res.data[0].report==undefined){//一次都没有没有上报体温
                  let arr2=[...that.data.notReported]
                  arr2.push(notRep)
                  that.setData({
                    notReported:arr2
                  })
                }else{
                  //上报过体温，判断是否今天上报过体温
                  //拿到report数组的长度
                  let ilen=res.data[0].report.length
                  //拿到report数组中最后面一个元素
                  console.log("最后一个元素",res.data[0].report[ilen-1])
                  //判断最后一个元素的日期是否和当天一致，一致表示已经上报，不一致表示未上报
                  if(Today==res.data[0].report[ilen-1].date){//一致,已上报
                    let arr3=[...that.data.Reported]
                    arr3.push({  
                      name:iname,
                      temp:res.data[0].report[ilen-1].temp
                    })
                    that.setData({
                      Reported:arr3
                    })
                  }else{//不一致，未上报
                    // number name major封装成对象并push进未上报数组
                    let arr4=[...that.data.notReported]
                    arr4.push(notRep)
                    that.setData({
                      notReported:arr4
                    })
                  }
                }  
              }
            },fail(res){
              console.log("查询第",i,"个成员失败",res)           
            }
          })
        }
       }
     }
   })
  },
  onPullDownRefresh () {
    setTimeout(function()

    {
       wx.stopPullDownRefresh() //停止下拉刷新
    },1500);
  }

})