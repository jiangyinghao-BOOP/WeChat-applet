//定义获取系统当前时间
var myDate=new Date();
//定义user数据表对象
const user=wx.cloud.database().collection('user')
//引用command方法
const _ =  wx.cloud.database().command
//使用dialog对话框
import Dialog from '../../@vant/weapp/dist/dialog/dialog';
Page({
  data: {
    radio1: '1.2',
    radio2: '2.2',
    radio3: '3.2',
    radio4: '4.2',
    radio5: '5.1',
    radio6: '6.1',
    radio7: '7.1',
    radio8: '8.1',
    radio9: '9',
    radioArry:[],
    //系统时间
    time:{
      year:'',
      month:'',
      date:'',
    },
    openid:""
  },
  onLoad:function(){
   const that = this
   //获取到用户openid
   wx.cloud.callFunction({
    name:'getOpenid',
    success(res){
      that.setData({
      openid:res.result.openid
      })
     console.log('获取openid成功',that.data.openid)
   },fail(err){
     console.log('获取openid失败',err)
   }
  })
  },
  onShow:function(){
   let Year = myDate.getFullYear();
   let Month=myDate.getMonth()+1;
   let Date=myDate.getDate();
   console.log(Year,Month,Date)
   this.setData({
     "time.year":Year,
     "time.month":Month,
     "time.date":Date,
   })
  },
  onChange1(event) {
    console.log(event.detail)
    this.setData({
      radio1: event.detail,   
    });
  },
  onChange2(event) {
    console.log(event.detail)
    this.setData({
      radio2: event.detail,
    });
  }, 
  onChange3(event) {
    console.log(event.detail)
    this.setData({
      radio3: event.detail,
    });
  },
  onChange4(event){
    console.log(event.detail)
    this.setData({
      radio4: event.detail,
    });
  },
  onChange5(event) {
    console.log(event.detail)
    this.setData({
      radio5: event.detail,
    });
  },
  onChange6(event) {
    console.log(event.detail)
    this.setData({
      radio6: event.detail,
    });
  },
  onChange7(event) {
    console.log(event.detail)
    this.setData({
      radio7: event.detail,
    });
  },
  onChange8(event) {
    console.log(event.detail)
    this.setData({
      radio8: event.detail,
    });
  },
  //承诺单选框s
  onChange9(event) {
    console.log(event.detail)
  },
  formSubmit:function(e){
    const that =this
    //拿到当天时间
    let date=that.data.time.year+'年'+that.data.time.month+'月'+that.data.time.date+'日'
    //拿到输入框输入的体温
    let temperature=e.detail.value.temperature
    //将radio值放进数组中
    console.log(temperature,typeof(parseInt(temperature)))
    console.log(that.data.radio1,typeof(parseInt(that.data.radio1)),that.data.radio1)
    let radio=e.detail.value
    //输入框和单选框都不为空
    if(temperature!=''&&that.data.radio1!=''&&that.data.radio2!=''&&that.data.radio3!=''&&that.data.radio4!=''&&
      that.data.radio5!=''&&that.data.radio6!=''&&that.data.radio7!=''&&that.data.radio8!=''&&that.data.radio9!=''){
      //检查体温数据是否输入合法
      if(temperature<35||temperature>42){
        Dialog.alert({
          message: '请输入35~42的合法数值',
        }).then(() => {
          // on close
        });
      }else{//体温数据合法,根据openid查询并向后台提交体温数据
        //根据openid查询user表,没有绑定学号信息不能上报体温
        user.where({_openid:that.data.openid}).get({
          success(res){
            console.log("根据openid查询绑定信息成功",res.data.length)
            //判断是否存在report字段
            //如果查询到的为空，说明没有绑定
            if(res.data.length==0){
              console.log(res.data.length)
              Dialog.confirm({
                message: '请先绑定信息',
                confirmButtonText:"去绑定",
                cancelButtonText:"下次吧"
              })
                .then(() => {
                  //绑定,跳转到绑定页面
                  wx.navigateTo({
                    url: '../bingding/bingding?openid='+that.data.openid
                  })
                })
                .catch(() => {
                  // on cancel
                });
            }else{//已经绑定好学号信息
                 console.log("已经绑定好信息")
                  //将要存到数据库的东西封装到一个对象里面
                  const data={
                    date:date,
                    temp:temperature
                  }
                let rep=res.data[0].report
                //没有存在report字段，可以直接存
                if(rep==undefined){
                  user.where({_openid:that.data.openid}).update({
                    data:{
                      report: _.push(data)
                    },
                    success(res){
                      console.log("第一次根据openid更新数据成功",res)
                      wx.showToast({
                        title: '提交成功',
                        icon:"success"
                      })
                    },fail(res){
                      console.log("第一次根据openid更新数据失败")
                    }
                  }) 
                }else{//存在report,判断当天是否已经上报过
                   //拿到report数组长度
                   let len = res.data[0].report.length
                   if(res.data[0].report[len-1].date==date){//已经上报过
                    console.log("今天已经上报过啦！！！！！")
                    //删除当天上报数据,取出最后一个元素
                    user.where({_openid:that.data.openid}).update({
                      data:{
                        report: _.pop()
                      },
                      success(res){
                        console.log("删除report数组最后一个元素成功",res)
                      },fail(res){
                        console.log("删除report数组最后一个元素成功失败")
                      }
                    })
                   }
                   //将本次上报的数据push进去
                   user.where({_openid:that.data.openid}).update({
                    data:{
                      report: _.push(data)
                    },
                    success(res){
                      console.log("修改当天数据成功",res)
                      wx.showToast({
                        title: '提交成功',
                        icon:"success"
                      })
                    },fail(res){
                      console.log("修改当天数据失败")
                    }
                  }) 
                }
            }
          },fali(res){
            console.log("根据openid查询绑定信息失败",res)
          }
        })
      }
    }else{
      wx.showToast({
        title: '请检查是否填写完整',
        icon: 'none',
      })
      console.log("请检查是否全部选中")
    }     
  },

});