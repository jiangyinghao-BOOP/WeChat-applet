//定义user数据表对象
const user=wx.cloud.database().collection('user')
//引用command方法
const _ =  wx.cloud.database().command
Page({
  data: {
   openid:'',
   //该用户没有小组显示，有小组不显示
   isMem:false,
   //存放小组信息的页面数组
   memArry:"",
   //显示弹窗
   show: false,
   //弹窗中输入的值
   nameInput:'',
   numberInput:'',
   authCodeInput:'',
   //添加成员是否存在当前小组中
   isExist:false
  },
  onLoad: function (options) {
    const that = this 
    that.setData({
     openid:options.openid
    })
  },
  onShow:function(){
    const that = this  
    /**查询是否有以member为key的本地缓存，如果有那么直接取出来，没有的话就向后台请求
     */
    //查询本地（使用同步的方式）
    wx.getStorage({
      key: 'member',
      success (res) {
        console.log("本地中数据",res.data)
        that.setData({
          memArry:res.data,
        })
      },fail(res){
        console.log(res)
       //向后台发起请求
        //根据openid查询
     user.where({_openid:that.data.openid}).get({
      success(res){
       console.log("根据openid查询成功",res.data)
       let mem=res.data[0].member
       //不存在member字段,无小组成员
       if(mem==undefined){
         console.log("该用户下无小组成员")
         that.setData({
           isMem:true
         })
       }else{//有小组成员
         //拿到member字段的数组mem,并赋值给页面数组memArry
         console.log("mem",mem)
         that.setData({
           memArry:mem
         })
         //将小组成员存到本地缓存中（异步的方式）
         wx.setStorage({
          key:"member",
          data:mem
        })
       }
      },fail(res){
        console.log("根据openid查询失败")
      }
    })
    }
    })
  },
  //添加成员的函数
  addMember:function(){
    //显示弹窗
    this.setData({
      show:true
    })
  },
  //拿到输入框的数据
  nameDateInput:function(e){
    this.data.nameInput = e.detail
  },
  numberDateInput:function(e){
    this.data.numberInput = e.detail
  },
  authCodeDateInput:function(e){
    this.data.authCodeInput = e.detail
  },
  //确认添加成员
  confirmAdd:function(e){
  //先根据输入信息查询是否存在该学生，存在添加，不存在提示错误
  const that = this 
   user.where({
      name:that.data.nameInput,
      number:that.data.numberInput,
      _id:that.data.authCodeInput
   }).get({
     success(res){
       console.log("添加成员查询成功",res.data.length)
       if(res.data.length){//存在该用户
          //拿到该用户的专业
          let major=res.data[0].major
          //将要存进数据库的信息封装成一个对象
          let info={
            name:that.data.nameInput,
            number:that.data.numberInput,
            major:major
          }
          //判断一下添加的成员是否存在当前小组中，如果存在不需要添加，不存在再继续添加
          for(let i =0;i<that.data.memArry.length;i++){
            if(info.name==that.data.memArry[i].name&&info.number==that.data.memArry[i].number
              &&info.major==that.data.memArry[i].major){//当前小组存在该成员
                that.setData({
                    isExist:true
                })
                 break;
              }
          }
          if(that.data.isExist){//为真表示当前小组存在该成员
            wx.showToast({
              title: '当前小组已存在该成员',
              icon:'none'
            })
          }else{//当前小组不存在该成员,将该成员添加到当前小组中
            console.log("正在努力将该成员添加到当前小组中")
            //将该成员的信息push进member数组中
            user.where({_openid:that.data.openid}).update({
              data:{ 
                member:_.push(info)
              },success(res){
                console.log("添加成员成功！",res)
                that.onShow()
                wx.showToast({
                  title: '添加成员成功',
                })
              },fail(res){
                console.log("添加成员失败！",res)
              }
            })
          }          
         //将这个对象push进数组中
       }else{//添加的该用户不存在
         wx.showToast({
           title: '请检查信息是否填写正确',
           icon:'none'
         })
       }
       //
     },fail(res){
     }
   })
  },
  //关闭弹窗
  onClose:function(){
  },
  //下拉刷新
  onPullDownRefresh () {
    var that = this
    wx.showNavigationBarLoading(); 
    //显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框
    wx.showLoading({
      title: '正在努力刷新',
    })
    //向后台查询
    user.where({_openid:that.data.openid}).get({
      success(res){
       console.log("根据openid查询成功",res.data)
       let mem=res.data[0].member
       //不存在member字段,无小组成员
       if(mem==undefined){
         console.log("该用户下无小组成员")
         that.setData({
           isMem:true
         })
       }else{//有小组成员
         //拿到member字段的数组mem,并赋值给页面数组memArry
         console.log("mem",mem)
         that.setData({
           memArry:mem
         })
         //将小组成员存到本地缓存中（异步的方式）
         wx.setStorage({
          key:"member",
          data:mem
        })
       }
      },fail(res){
        console.log("根据openid查询失败")
      }
    })
    //停止调用
    wx.hideLoading()
  }
})