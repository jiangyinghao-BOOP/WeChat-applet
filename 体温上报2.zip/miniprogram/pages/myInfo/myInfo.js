//定义数据库对象
const user=wx.cloud.database().collection('user')
Page({
  data: {
    openid:'',
    name:'',
    number:'',
    major:'',
    identity:'',
    authCode:'',
    weChatid:'' 
  },
  //加载个人信息
  onLoad:function(option){
    console.log(option)
    const that = this
    that.setData({
      openid:option.openid
    })
    /**
     * 1.判断本地中是否存在以myInfo为key的数据
     * 如果存在表示已经向后台数据库发起过查询请求，直接在本地取即可
     * 如果不存在表示数据第一次进入页面，需要向数据库发起查询请求
     */
     //使用同步的方法拿到以myInfo为key的数据
     wx.getStorage({
      key: 'myInfo',
      success (res) {
        console.log(res.data)
        //将从本地拿到的数据赋值给页面数据
        that.setData({
          name:res.data.name,
          number:res.data.number,
          major:res.data.major,
          identity:res.data.identity,
          authCode:res.data.authCode
        })
      },
      //查询失败也就是第一次进页面，进入查询
      fail(res){
        console.log(res)
        console.log("本地中没有")
          console.log("没有在本地缓存中查到")
           //根据openid查询数据表
          user.where({_openid:that.data.openid}).get({
          success(res){
            console.log("根据openid查询user数据表成功",res)
            //将向后台发起的请求拿到的数据赋值给页面数据
            that.setData({
              name:res.data[0].name,
              number:res.data[0].number,
              major:res.data[0].major,
              identity:res.data[0].identity,
              authCode:res.data[0]._id
            })
            //将向后台发起的请求拿到的数据存到本地（异步的方式）
            wx.setStorage({
              key:"myInfo",
              data:{
                name:res.data[0].name,
                number:res.data[0].number,
                major:res.data[0].major,
                identity:res.data[0].identity,
                authCode:res.data[0]._id
              }
            })
          },fail(res){
            console.log("根据openid查询user数据表失败",res)
          } 
        })
      }
        })
  },
})
