//定义数据库对象
const db=wx.cloud.database().collection('student')
const user=wx.cloud.database().collection('user')
Page({
  data: {
    name:"",
    number:"",
    major:"",
    identity:"",
    openid:""
  },
  onLoad:function(option){
    this.setData({
      openid:option.openid
    })
    console.log("onload",this.data.openid)
  },
  //提交表单完成的功能
  //1.获取到输入的学号密码数据
  //2.向后台数据库请求验证学号是否存在，密码是否正确
  //3.微信授权，方便下次登陆
  //4.跳转到主页面
  formSubmit: function(e) {
    let that=this
   //拿到输入的学号和密码
   let number=e.detail.value.number
   let passwd=e.detail.value.passwd
   //验证学号和密码
   db.where({
    number:number,
    passwd:passwd
   }).get({
    success: function(res) {
      console.log("调用验证接口成功！",res)
      /*查的到就有记录，查不到就没有记录 */
      if(res.data.length==0){
        wx.showToast({
          title: '学号或者密码错误',
             icon: 'none'
        })
      }else{
        console.log("验证学号密码成功！")
        //拿到student表中的对应的数据
        let name1=res.data[0].name
        let number1=res.data[0].number
        let major1=res.data[0].major
        let identity1=res.data[0].number
         that.setData({
           name:name1,
           number:number1,
           major:major1,
           identity:identity1
         })
         /* 将此学生的信息添加到openid对应的user表中*/
         //判断该用户对应的openid下是否在user表中有记录，利用openid查询
         user.where({_openid:that.data.openid}).get({
           success(res){
            console.log("利用openid查询user表成功")
            if(res.data.length>=1){
              wx.showToast({
                title: '该学号已被绑定',
                icon:"none"
              })
              console.log("该学号已被绑定，请检查，如有疑问请联系管理员")
            }else{
              //学号和密码正确之后将信息添加到user集合中，添加新的记录
              user.add({
                data:{
                  name:that.data.name,
                  number:that.data.number,
                  major:that.data.major,
                  identity:that.data.identity 
                },
                success(res){
                  console.log("添加记录成功",res)
                  wx.showToast({
                    title: '绑定成功',
                  })
                  //绑定成功后跳转到我的页面
                  wx.switchTab({
                    url: '../myPerson/myPerson',
                  })
                }
              })    
            }
           },fail(res){
             console.log("利用openid查询user表失败")
           }
         })
         
      }
    },fail(res){
       console.log("调用验证接口失败",res)
    }
   })
  }
})