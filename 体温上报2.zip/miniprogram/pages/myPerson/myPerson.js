//定义student数据表对象
const DB=wx.cloud.database().collection('student')
//定义user数据表对象
const user=wx.cloud.database().collection('user')
Page({
  data: {
    arrow:'../../images/arrow_right.png',
    //用户名
    username:'',
    openid:'',
    // 绑定状态
    status:false
  },
  /*调用一次，第一次进入小程序页面时调用*/
  onLoad:function(){
    let that =this
    //获取用户openid
    wx.cloud.callFunction({
      name:'getOpenid',
      success(res){
        that.setData({
        openid:res.result.openid
        })
       console.log('获取openid成功',that.data.openid)
     },fail(err){
       console.log('获取openid失败',err)
     }
    })
  },
  /*
  每次渲染这个页面时调用onShow函数
   */
  onShow:function(){
    let that = this
    //根据oppenid查询
    user.where({_openid:that.data.openid}).get({
      success(res){
        console.log("根据openid查询user集合成功",res)
        //第一次进入页面根据opennid查询不到,那么我们就重新调用这个onShow
        if(res.data.length==0){
          that.onShow()
        }
        //改变绑定状态,拿到该openid对应user集合中姓名
        let username=res.data[0].name
        that.setData({
          status:true,
          username:username
        })
      },
      fail(res){
        console.log('失败',res)
      }
     })
    //未登陆
    if(that.data.status==''){
      console.log("用户未绑定信息")
    }else{
      console.log("用户已绑定信息")
    }
    console.log("onshow")
  },
  //跳转到bingding页面去绑定信息
  bingding(){
    console.log(this.data.openid)
    wx.navigateTo({
      url: '../bingding/bingding?openid='+this.data.openid
    })
  }
})