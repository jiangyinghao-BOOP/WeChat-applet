// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
//定义数据库对象
const db=wx.cloud.database().collection('student')
// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
    db.where({_id:"5ca99db15f351c0900052ecd5a528a2a"}).update({
      data:{
        major:"计算机"
      },
      success(res){
        console.log("更新成功",res.data)
      }
    })
  return {
  
  }
}